<?php $name = "English";
$pagename = "LanguageTransaltion";
$tarrif = "Tarrif";
$mobileapp = "Mobile App";
$partnerwithus = "Partner with as";
$signup = "Sign up";
$login = "Login";
$id = "1";
 ?>